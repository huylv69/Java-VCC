 -- 1.1. Liệt kê 10 nhân viên bắt đầu làm việc từ năm 1999
select  *
from employees
where year(hire_date) >= 1999
limit 10;

 -- 1.2. Đếm số nhân viên nữ có ngày sinh từ năm 1950 đến năm 1960 mà last_name có 3 chữ cái đầu là “Mon”
select count(emp_no)
from employees
where employees.gender = 'M'
and year(birth_date) between 1950 and 1960
and last_name like 'Mon%';

-- 1.3. Lấy ra các nội dung sau của nhân viên có id = 10005: first_name, last_name, hire_date, salary_total. Trong đó salary_total là tổng lương của nhân viên 10005 trong toàn bộ thời gian anh ta giữ chức vụ “Staff” – trong bảng titles
SELECT first_name, last_name, hire_date, (select sum(salary) from salaries where emp_no = 10005 and salaries.to_date <= (select to_date from titles where emp_no = 10005 and titles.title = 'Staff')) as salary_total
FROM employees
where emp_no = 10005
;

 -- 1.4. Tìm xem người quản lý có tên là Margareta Markovitch trong thời gian giữ chức quản lý thì đã quản lý bao nhiêu nhân viên
select count(emp_no) 
from dept_emp 
where dept_no = (SELECT dept_no  FROM employees.dept_manager where emp_no=(SELECT emp_no FROM employees.employees where first_name = 'Margareta' and last_name = 'Markovitch'))
and to_date > (SELECT from_date FROM employees.dept_manager where emp_no=(SELECT emp_no FROM employees.employees where first_name = 'Margareta' and last_name = 'Markovitch'))
or from_date < (SELECT to_date FROM employees.dept_manager where emp_no=(SELECT emp_no FROM employees.employees where first_name = 'Margareta' and last_name = 'Markovitch'));


-- 1.5. Tìm xem tổng lương phải trả của mỗi phòng ban trong khoản thời gian from_date = 1988-06-25 đến to_date 1989-06-25 (from_date, to_date từ bảng salaries) là bao nhiêu và lọc những phòng ban trả tổng lương cao hơn 3 triệu$.
select dept_emp.dept_no , sum(salary) as salaries  from dept_emp ,salaries 
where dept_emp.emp_no = salaries.emp_no
and salaries.from_date = '1988-06-25'
and salaries.to_date = '1989-06-25'
group by dept_no
having sum(salary)<3000000;

-- 2.1. Thăng chức cho nhân viên 10002 từ “Staff” lên “Senior Staff”. Lưu ý, phải dừng chức vụ hiện tại mới được chuyển chức vụ mới.
update titles
set to_date = date(now())
where emp_no= 10002
and to_date ='9999-01-01';

insert into titles(emp_no,title,from_date,to_date)
values( 10002,'Senior Staff',date(now()) , '9999-01-01');

-- 2.2. Hãy xóa phòng ban Production cùng toàn bộ nhân viên của phòng này, cùng với tất cả các dữ liệu có liên quan.
SET SQL_SAFE_UPDATES = 0;
DELETE FROM employees.employees where emp_no in (select emp_no from dept_emp where dept_no=(select dept_no from departments where dept_name ='Marketing'));
DELETE FROM employees.employees where emp_no in (select emp_no from dept_manager where dept_no= (select dept_no from departments where dept_name ='Marketing'));
DELETE FROM employees.departments where dept_name = "Marketing";
SET SQL_SAFE_UPDATES = 1;

-- 2.3. Thêm phòng ban mới “Bigdata & ML” và bổ nhiệm nhân viên có ID = 10173 lên làm quản lý. 
insert into departments (dept_no,dept_name) 
value ('d010','Bigdata & ML');

insert into dept_manager(dept_no,emp_no,from_date,to_date)
value('d010',10173,date(now()),'9999-01-01');

update titles
set to_date = date(now())
where emp_no= 10173
and to_date ='9999-01-01';

insert into titles(emp_no,title,from_date,to_date)
values( 10173,'Manager',date(now()) , '9999-01-01');


--3. Viết một Stored Procedure với input là tên nhân viên. Cần trả lại 2 result - kết quả :
--  3.1. Kết quả 1: Lấy ra id, full name, giới tính, title (hay  chức vụ), tên phòng ban
--  3.2. Kết quả 2: Tính tổng lương của từng người có tên đó trong khoảng thời gian từ lúc nhận lương đến thời điểm hiện tại
CREATE DEFINER=`root`@`localhost` PROCEDURE `find_info`(
IN Employee_Name nvarchar(200)
)
BEGIN
    select employees.emp_no,  gender, title, dept_name ,concat(employees.first_name ,' ', employees.last_name) AS full_name from employees,titles,departments, dept_emp where dept_emp.emp_no = employees.emp_no and titles.emp_no = employees.emp_no and dept_emp.dept_no = departments.dept_no and first_name = Employee_Name
    union 
	select employees.emp_no,  gender, title, dept_name ,concat(employees.first_name ,' ', employees.last_name) AS full_manager from employees,titles,departments, dept_emp where dept_emp.emp_no = employees.emp_no and titles.emp_no = employees.emp_no and dept_emp.dept_no = departments.dept_no and first_name = Employee_Name    ;
    
    select employees.emp_no,concat(employees.first_name ,' ', employees.last_name) AS full_name , sum(salary) as salary 
    from salaries,employees 
    where salaries.emp_no = employees.emp_no
    and first_name = Employee_Name
    and salaries.to_date < date(now())
    group by salaries.emp_no ;
END

-- 4. Viết một Store Procedure để thuyên chuyển phòng ban cho một nhân viên nào đó, với chức vụ mới (không chuyển lên làm quản lý). Đồng thời trả lại một kết quả bao gồm:
--  ra id, full name, giới tính, title (hay  chức vụ), tên phòng ban 

CREATE DEFINER=`root`@`localhost` PROCEDURE `promote`(
IN Employee_ID int,
IN Employee_Dept nvarchar(200),
IN Employee_Title nvarchar(200)

)
BEGIN
	IF Employee_Title  = 'Manager' then 
		Select  employees.emp_no,  gender, title, dept_name ,concat(employees.first_name ,' ', employees.last_name) AS full_name from employees,titles,departments, dept_emp where dept_emp.emp_no = employees.emp_no and titles.emp_no = employees.emp_no and dept_emp.dept_no = departments.dept_no and employees.emp_no = Employee_ID;
	ELSE
        update dept_emp
		set to_date = date(now())
		where emp_no= Employee_ID
		and to_date ='9999-01-01';
		insert into dept_emp(emp_no,dept_no,from_date,to_date)
		values( Employee_ID,Employee_Dept,date(now()) , '9999-01-01');
        
        update titles
		set to_date = date(now())
		where emp_no= Employee_ID
		and to_date ='9999-01-01';
		insert into titles(emp_no,title,from_date,to_date)
		values( Employee_ID,Employee_Title,date(now()) , '9999-01-01');
	END IF;
	Select  employees.emp_no,  gender, title, dept_name ,concat(employees.first_name ,' ', employees.last_name) AS full_name from employees,titles,departments, dept_emp where dept_emp.emp_no = employees.emp_no and titles.emp_no = employees.emp_no and dept_emp.dept_no = departments.dept_no and employees.emp_no = Employee_ID and titles.to_date ='9999-01-01' and departments.dept_no =  Employee_Dept;

END

