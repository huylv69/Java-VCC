hadoop fs -text /user/huylv/sample/* | hadoop fs -put - /user/huylv/filename.txt
