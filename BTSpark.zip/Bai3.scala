import spark.implicits._
import java.sql.Timestamp
import org.apache.spark.sql.types._
import org.apache.spark.sql._
import  org.apache.spark.sql.SQLContext
case class Logs (
timeCreate : Timestamp, //0
cookieCreate:Timestamp, //1
browserCode : Int, //2 
browserVer : String, //3
osCode : Int, //4
osVer : String, //5
ip : Long,  //6
locId : Int, //7
domain : String, //8
siteId : Int,//9
cId : Int, //10
path : String,//11
referer : String, //12
guid : Long, //13
flashVersion : String, //14
jre : String, //15
sr : String, //16
sc : String, //17
geographic : Int //18
//category: Int //23
)

val logsDF = spark.sparkContext.textFile("/home/huylv/Desktop/Kmean/data.txt").map(_.split("\t")).map(line => Logs(Timestamp.valueOf(line(0)),Timestamp.valueOf(line(1)),line(2).toInt,line(3).toString,line(4).toInt,line(5).toString,line(6).toLong,line(7).toInt,line(8).toString,line(9).toInt,line(10).toInt,line(11).toString,line(12).toString,line(13).toLong,line(14).toString,line(15).toString,line(16).toString,line(17).toString,line(18).toInt)).toDF()
logsDF.show()
logsDF.createOrReplaceTempView("logsDF")

//a
val tempDF =  spark.sqlContext.sql("select guid , domain, COUNT (domain) as turn FROM logsDF GROUP BY guid, domain")
tempDF.createOrReplaceTempView("tempDF")
val sqlDF2 = spark.sql("SELECT guid ,domain, MAX(turn) FROM tempDF GROUP BY guid, domain order by MAX(turn) DESC ") 
sqlDF2.show(30,false)

//b
val sqlDF1 = spark.sql("SELECT ip, COUNT(DISTINCT guid) as number FROM logsDF Group by ip ORDER BY number DESC ")
sqlDF1.show(30,false)

//c
val sqlDF1 = spark.sql("SELECT guid FROM logsDF WHERE (unix_timestamp(timeCreate) - unix_timestamp(cookieCreate))/3600 < 1800")
sqlDF1.show(30,false)
